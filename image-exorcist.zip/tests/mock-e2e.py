"""Browser-level Spindle mock: python tests/mock-e2e.py (requires Playwright + Chromium)."""
from pathlib import Path
from playwright.sync_api import sync_playwright

ROOT = Path(__file__).resolve().parents[1]
SCRIPT = (ROOT / 'dist' / 'frontend.js').read_text()
RED = 'data:image/svg+xml,%3Csvg xmlns=%22http://www.w3.org/2000/svg%22 width=%2260%22 height=%2260%22%3E%3Crect width=%2260%22 height=%2260%22 fill=%22red%22/%3E%3C/svg%3E'

MOCK = r'''
window.__fakeStyles = new Set();
window.__storageMap = new Map();
Object.defineProperty(window, 'localStorage', {configurable:true, value: {
  getItem(k){return window.__storageMap.has(k) ? window.__storageMap.get(k) : null;},
  setItem(k,v){window.__storageMap.set(k,String(v));},
  removeItem(k){window.__storageMap.delete(k);}
}});
window.__ctx = {
  dom: {addStyle(css) {
    const s = document.createElement('style'); s.textContent = css;
    document.head.appendChild(s); window.__fakeStyles.add(s);
    return () => {s.remove(); window.__fakeStyles.delete(s);};
  }},
  ui: {
    registerDrawerTab(options) {
      const root = document.createElement('section');
      root.id = 'drawer-root'; document.body.appendChild(root);
      window.__mockTab = {root,options};
      return {root, destroy(){root.remove();}};
    },
    registerInputBarAction(options) {
      window.__quick = {label: options.label, handler:null};
      return {
        onClick(fn){ window.__quick.handler = fn; return () => {window.__quick.handler = null;} },
        setLabel(text){ window.__quick.label = text; },
        destroy(){ window.__quick.destroyed = true; }
      };
    }
  }
};
'''

with sync_playwright() as pw:
    browser = pw.chromium.launch(headless=True, executable_path='/usr/bin/chromium', args=['--no-sandbox'])
    page = browser.new_page()
    page.set_content('''<!doctype html><html><head><style>.pseudo::before{content:"";display:block;width:60px;height:60px;background-image:url(https://example.com/pseudo.png)} .grad{background-image:linear-gradient(red,blue)}</style></head><body>
        <img id="avatar" width="60" height="60" src="REPLACE_ME">
        <div id="banner" style="width:60px;height:60px;background-image:url(https://example.com/banner.png)"></div>
        <span id="pseudo" class="pseudo"></span>
        <span id="gradient" class="grad"></span>
        <svg height="60" width="60"><image id="svg-art" href="REPLACE_ME" width="60" height="60"/></svg>
    </body></html>'''.replace('REPLACE_ME', RED))
    page.add_script_tag(content=MOCK)
    # Keep module and test setup in same module scope.
    page.add_script_tag(type='module', content=SCRIPT+'\nwindow.__setup = setup; window.__cleanup = setup(window.__ctx); window.__ready = true;')
    page.wait_for_function('window.__ready && document.querySelector("#banner[data-ie-background]")')
    assert page.locator('html.ie-exorcist-active').count() == 1
    assert page.locator('#avatar').get_attribute('src') == RED, 'Do not touch host <img> src'
    assert 'IMAGE%20REVOKED' in page.locator('#avatar').evaluate('el => getComputedStyle(el).content')
    assert 'IMAGE%20REVOKED' in page.locator('#banner').evaluate('el => getComputedStyle(el).backgroundImage')
    assert page.locator('#pseudo').get_attribute('data-ie-before-bg') is not None
    assert page.locator('#gradient').get_attribute('data-ie-background') is None, 'Keep CSS gradients intact'
    assert 'data:image' in page.locator('#svg-art').get_attribute('href')
    print('PASS: default placeholder; originals untouched; SVG and backgrounds patched; gradients spared')

    page.evaluate('''() => {const img=document.createElement('img'); img.id='streamed'; img.src='https://example.com/stream.png'; document.body.appendChild(img);
      const banner=document.createElement('div'); banner.id='dynamic-background'; banner.style.backgroundImage='url(https://example.com/new.png)'; document.body.appendChild(banner);}''')
    page.wait_for_function('document.querySelector("#dynamic-background[data-ie-background]")')
    assert 'IMAGE%20REVOKED' in page.locator('#streamed').evaluate('el => getComputedStyle(el).content')
    print('PASS: newly mounted image and CSS background work after DOM changes')

    page.locator('[data-ie-input="mode"]').select_option('hide')
    page.wait_for_function('getComputedStyle(document.querySelector("#avatar")).visibility==="hidden"')
    assert page.locator('#svg-art').get_attribute('href') == RED, 'SVG href restored in hide mode'
    assert page.locator('#banner').evaluate('el=>getComputedStyle(el).backgroundImage') == 'none'
    print('PASS: hide mode preserves elements but suppresses their pictures')

    page.locator('[data-ie-input="includeBackgrounds"]').uncheck()
    assert 'banner.png' in page.locator('#banner').evaluate('el=>getComputedStyle(el).backgroundImage')
    print('PASS: background checkbox truly disables background replacement')

    page.locator('[data-ie-input="includeBackgrounds"]').check()
    page.locator('[data-ie-input="source"]').fill('https://example.com/curse.png')
    page.locator('[data-ie-input="source"]').dispatch_event('change')
    assert page.locator('[data-ie-input="mode"]').input_value() == 'custom'
    assert 'curse.png' in page.locator('#avatar').evaluate('el => getComputedStyle(el).content')
    assert 'curse.png' in page.locator('#banner').evaluate('el => getComputedStyle(el).backgroundImage')
    assert page.locator('#svg-art').get_attribute('href') == 'https://example.com/curse.png'
    print('PASS: custom picture replaces img, CSS backgrounds, SVG images')

    page.locator('[data-ie-input="enabled"]').uncheck()
    assert page.locator('html.ie-exorcist-active').count() == 0
    assert page.locator('#svg-art').get_attribute('href') == RED
    assert 'banner.png' in page.locator('#banner').evaluate('el=>getComputedStyle(el).backgroundImage')
    assert page.locator('#avatar').evaluate('el=>getComputedStyle(el).content') == 'normal'
    print('PASS: off is reversible')

    page.evaluate('window.__quick.handler()')
    assert page.locator('html.ie-exorcist-active').count() == 1
    assert 'curse.png' in page.locator('#avatar').evaluate('el => getComputedStyle(el).content')
    print('PASS: composer quick toggle')

    # PNG chosen from the browser file picker persists without touching the backend.
    png_bytes = bytes.fromhex('89504e470d0a1a0a0000000d49484452000000010000000108060000001f15c4890000000b49444154789c636000020000050001a5f645400000000049454e44ae426082')
    page.locator('[data-ie-input="file"]').set_input_files({
        'name': 'local-pixel.png', 'mimeType': 'image/png', 'buffer': png_bytes
    })
    page.wait_for_function('getComputedStyle(document.querySelector("#avatar")).content.includes("data:image/png;base64")')
    assert 'data:image/png;base64,' in page.evaluate('window.__storageMap.get("image_exorcist_settings_v1")')
    print('PASS: local image file and browser-only persistence')

    # Prove existing custom selection reloads after cleanup/re-setup.
    page.evaluate('() => { window.__cleanup(); window.__cleanup = window.__setup(window.__ctx); return true; }')
    page.wait_for_function('getComputedStyle(document.querySelector("#avatar")).content.includes("data:image/png;base64")')
    assert page.locator('[data-ie-input="mode"]').input_value() == 'custom'
    assert page.locator('#svg-art').get_attribute('href').startswith('data:image/png;base64,')
    print('PASS: persisted settings rehydrate on new setup')

    page.evaluate('window.__cleanup()')
    assert page.locator('html.ie-exorcist-active').count() == 0
    assert page.locator('#svg-art').get_attribute('href') == RED
    assert page.locator('#banner').get_attribute('data-ie-background') is None
    assert 'banner.png' in page.locator('#banner').evaluate('el=>getComputedStyle(el).backgroundImage')
    assert page.locator('#drawer-root').count() == 0
    assert page.evaluate('window.__fakeStyles.size') == 0
    print('PASS: unmount cleans up observers, stylesheet, drawer, DOM flags, SVG hrefs')
    browser.close()

print('All mock-host browser checks passed.')
